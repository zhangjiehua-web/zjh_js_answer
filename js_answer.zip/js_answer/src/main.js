// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import axios from 'axios'
// 全局统一配置
import Config from './common/Config' // 统一全局配置
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import curdUtil from './common/utils/CurdUtils'
import commonUtil from './common/utils/CommonUtils'
import Mock from './mock' //  引入mockjs
import layer from 'vue-layer' //  引入弹窗插件npm i --save vue-layer
import 'vue-layer/lib/vue-layer.css'

Vue.use(ElementUI)

Vue.config.productionTip = false
Vue.prototype.$axios = axios
Vue.prototype.$Config = Config // 统一全局配置
Vue.prototype.$commonUtil = commonUtil
Vue.prototype.$curdUtil = curdUtil
Vue.prototype.$mock = Mock
Vue.prototype.$layer = layer(Vue)

// 登录
// router.beforeEach((to, from, next) => {
//   if (sessionStorage.sgcc_user) { // 判断是否有token
//     next()
//   } else {
//     if (to.path === '/login') {
//       next()
//     } else {
//       next('/login')
//     }
//   }
// })
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
