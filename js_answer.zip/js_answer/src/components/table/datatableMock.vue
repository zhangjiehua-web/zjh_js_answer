<template>
  <div>
    <div class="queryCondition">
      <el-button type="primary" @click="query"><i class="el-icon-search"></i> 查询</el-button>
    </div>
    <!-- 控制按钮 -->
    <div class="toolbar-group">
      <el-button type="text" @click="insert"><i class="el-icon-plus"></i> 新增</el-button>
      <el-button type="text" @click="updata"><i class="el-icon-edit"></i> 修改</el-button>
      <el-button type="text"><i class="el-icon-delete"></i> 删除</el-button>
      <el-button type="text"><i class=""></i> 导入</el-button>
      <el-button type="text"><i class=""></i> 导出</el-button>
      <el-button type="text" @click="toggleSelection([tableData[1], tableData[2]])">切换第二、第三行的选中状态</el-button>
      <el-button type="text" @click="toggleSelection()">取消选择</el-button>
    </div>
    <el-table ref="multipleTable" :data="tableData" stripe style="width:98%;margin: 0 auto"  height="450" align="center" border @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="name" label="姓名"  align="center"></el-table-column>
      <el-table-column prop="age" label="年龄"  align="center"></el-table-column>
      <el-table-column prop="birthday" label="出生日期"  align="center"></el-table-column>
      <el-table-column prop="city" label="地址"  align="center"></el-table-column>
    </el-table>
    <el-pagination background small :page-sizes="page.pageSizes" :current-page="page.currentPage" :page-size="page.pageSize" :pager-count=5 layout="total, sizes, prev, pager, next, jumper" :total="page.total" @current-change="currentChange" @size-change="sizeChange"></el-pagination>
  </div>
</template>

<script>
let _this = null
let url = {
  query: '/api/users'
}
export default {
  name: 'datable',
  data () {
    return {
      // 分页信息
      // page: {total: 0, pageSize: 10, currentPage: 1, pageSizes: [10, 50, 100]},
      tableData: [],
      tableDataint: [],
      layer_area: ['800px', '450px'],
      multipleSelection: [] // 选中行
    }
  },
  created () {
    _this = this
    //  初始化查询
    _this.query()
    //  初始化分页
    _this.$commonUtil.init(_this)
  },
  methods: {
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    query: function () {
      //  get  post请求均可访问mock的表格数据
      _this.$axios.post(url.query).then(res => {
        // console.log(res)
        _this.tableDataint = res.data.user
        _this.page.total = _this.tableDataint.length
        _this.tableData = _this.tableDataint.slice((_this.page.currentPage - 1) * _this.page.pageSize, _this.page.currentPage * _this.page.pageSize)
      })
    },
    insert: function () {
      _this.layerOpen('新增', require('./insert'), {})
    },
    updata: function () {
      if (this.multipleSelection.length > 1) {
        this.$message.warning('只能同时修改一条数据！')
      } else if (this.multipleSelection.length < 1) {
        this.$message.warning('请选择一条数据进行修改！')
      } else {
        let data = {
          insrtform: _this.multipleSelection[0],
          info: {
            a: 1
          }
        }
        _this.layerOpen('修改', require('./insert'), data)
      }
    },
    // 打开弹窗
    layerOpen: function (title, page, data) {
      let config = {
        title: title,
        area: _this.layer_area,
        content: {
          content: page.default,
          parent: this, //  当前的vue对象
          data: data
        },
        cancel: (res) => { // 关闭事件
          this.$message.warning(res)
          // _this.$layer.alert('关闭iframe')
        }
      }
      _this.$layer.iframe(config)
    }
  }
}
</script>

<style scoped>
.queryCondition{
  margin: 0 auto;
  padding: 0;
  width: 98%;
  height: 100px;
  border: 1px solid #ccc;
  opacity:0.5;
}
</style>
