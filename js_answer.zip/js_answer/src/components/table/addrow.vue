<template>
    <div class="tablewrap" :style="{height:(screenHeight - 130) +'px'}">
      <el-form :model="insertForm" ref="insertForm">
        <el-button type="text" @click="insertRow"><i class="fa fa-plus"></i> 新增</el-button>
        <el-button type="text" @click="deleteRow"><i class="fa fa-trash-o"></i> 删除</el-button>
        <el-table  class="table-de" :data="insertForm.tableData" stripe highlight-current-row @row-click="rowClick">
          <el-table-column align="center" label="序号" width="56">
            <template slot-scope="scope">
              {{scope.$index+1}}
            </template>
          </el-table-column>
          <el-table-column show-overflow-tooltip label="交易名称">
            <template slot-scope="scope">
              <el-form-item :prop="`tableData.${scope.$index}.memberName`" :rules='insertForm.insertFormRules.memberName'>
                <el-row class="combox">
                  <el-input v-model="scope.row.memberName" placeholder="请输入"></el-input>
                </el-row>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column align="center" show-overflow-tooltip label="替代上网电量">
            <template slot-scope="scope">
              <el-form-item  :prop="`tableData.${scope.$index}.alterPq`"  :rules='insertForm.insertFormRules.alterPq'>
                <el-input v-model="scope.row.alterPq" placeholder="请输入"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column align="center" show-overflow-tooltip label="被替代电量">
            <template slot-scope="scope">
              <el-form-item  :prop="`tableData.${scope.$index}.byAlterPq`"  :rules='insertForm.insertFormRules.byAlterPq'>
                <el-input v-model="scope.row.byAlterPq" placeholder="请输入"></el-input>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column align="center" label="结算月份">
            <template slot-scope="scope">
              <el-form-item  :prop="`tableData.${scope.$index}.settleYm`" :rules='insertForm.insertFormRules.settleYm'>
                <el-date-picker
                  v-model="scope.row.settleYm"
                  type="month"
                  format="yyyyMM"
                  value-format="yyyyMM"
                  placeholder="请选择">
                </el-date-picker>
              </el-form-item>
            </template>
          </el-table-column>
          <el-table-column align="center" label="状态">
            <template slot-scope="scope">
              <el-form-item  :prop="`tableData.${scope.$index}.useState`" :rules='insertForm.insertFormRules.useState'>
                <el-select clearable v-model="scope.row.useState" placeholder="请选择">
                  <el-option
                    v-for="item in useState"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
    </div>
</template>

<script>
let _this = null
export default {
  name: 'addrow',
  data () {
    return {
      screenHeight: document.documentElement.clientHeight, // 屏幕高度
      useState: [{
        value: '1',
        label: '黄金糕'
      }, {
        value: '2',
        label: '双皮奶'
      }, {
        value: '3',
        label: '蚵仔煎'
      }, {
        value: '4',
        label: '龙须面'
      }, {
        value: '5',
        label: '北京烤鸭'
      }],
      selectedRow: {},
      insertForm: {
        tableData: [],
        // 数据监测
        insertFormRules: {
          memberName: [
            {required: true, message: '请输入交易名称', trigger: ['blur', 'change']}
          ],
          alterPq: [
            {required: true, message: '请输入替代上网电量', trigger: ['blur', 'change']}
          ],
          byAlterPq: [
            {required: true, message: '请输入被替代电量', trigger: ['blur', 'change']}
          ],
          settleYm: [
            {required: true, message: '请选择结算月份', trigger: ['blur', 'change']}
          ],
          useState: [
            {required: true, message: '请选择结状态', trigger: ['blur', 'change']}
          ]
        }
      }
    }
  },
  // 页面初始化加载方法
  created: function () {
    _this = this
    console.log(_this.$Config)
  },
  // 方法区
  methods: {
    // 添加一空行
    insertRow () {
      _this.insertForm.tableData.push({
        ind: _this.insertForm.tableData.length,
        memberName: '',
        memberCode: '',
        alterPq: '',
        byAlterPq: '',
        settleYm: '',
        useState: ''
      })
    },
    // 选择一行
    rowClick: function (row, column, event) {
      _this.selectedRow = row
    },
    // 删除一行
    deleteRow () {
      if (!_this.selectedRow.hasOwnProperty('memberName')) {
        this.$message.error('请选择一条数据进行删除')
      } else {
        for (let i = 0; i < _this.insertForm.tableData.length; i++) {
          if (_this.selectedRow.ind === _this.insertForm.tableData[i].ind) {
            _this.insertForm.tableData.splice(i, 1)
            _this.selectedRow = {}
            break
          }
        }
      }
    }
  }
}
</script>

<style  lang="scss">
  .tablewrap{
    /*border: 1px solid #FF9900;*/
    overflow-y: auto;
    width: 100%
  }
  .el-form-item {
     margin-bottom: 0!important
  }
  .table-de {
    .el-form-item__error {
      color: #fff;
      font-size: 12px;
      line-height: 1;
      position: absolute;
      bottom: -8px;
      top: unset;
      left: 0;
      border-radius: 2px;
      background-color: #FF9900;
      padding: 2px 4px;
      z-index: 1;
    }
  }
</style>
