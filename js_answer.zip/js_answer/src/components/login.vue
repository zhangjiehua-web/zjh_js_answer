<template>
  <div class="loginMain">
    <div class="login-container">
      <el-form :inline="true" :model="logForm" :rules="rules" ref="ruleForm" label-position="left" class="demo-ruleForm" label-width="100px">
        <el-form-item prop="username" label="用户名">
          <el-input type="text" v-model="logForm.username" auto-complete="off" placeholder="账号"></el-input>
        </el-form-item>
        <el-form-item prop="password" label="密码" >
          <el-input type="password" v-model="logForm.password" auto-complete="off" @keyup.enter.native="submitForm('ruleForm')" placeholder="密码" ></el-input>
        </el-form-item>
        <el-form-item class="btn-mg">
          <el-button type="images" @click="submitForm('ruleForm')">登录</el-button>
          <el-button type="images" @click="resetQueryForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
let _this = null
// let url = {
//   log: 'userManager/login'
// }
export default {
  name: 'login',
  data: function () {
    return {
      logForm: {
        username: null,
        password: null
      },
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      }
    }
  },
  created: function () {
    _this = this
  },
  methods: {
    // 查询条件重置
    resetQueryForm: function (formName) {
      debugger
      _this.$refs[formName].resetFields()
    },
    submitForm (formName) {
      // console.log(_this.logForm)
      this.$refs.ruleForm.validate(valid => {
        if (valid) {
          _this.$axios.post('/api/login').then(res => {
            sessionStorage.setItem(_this.$Config.logInfo.user, JSON.stringify(res.data.token))
            this.$message.success('登录成功')
            _this.$router.push({ path: '/home' })
          }).catch(
            this.$message.err('登录失败')
          )
        } else {
          this.$message.warning('请输入用户名和密码')
          return false
        }
      })
      // this.$refs[formName].validate((valid) => {
      //   if (valid) {
      //     // 访问借口验证数据
      //     let config = { headers: { 'Content-Type': 'application/json;charset=UTF-8' } }
      //     _this.$http.post(_this.$commonUtilV2.getUrl(_this, url.log), _this.logForm, config).then((res) => {
      //       if (_this.$commonUtilV2.checkResultData(res)) {
      //         // 登录成功处理
      //         let userData = res.data.resultValue
      //         sessionStorage.setItem(_this.$Config.logInfo.user, JSON.stringify(userData))
      //         _this.$router.push('/')
      //       } else {
      //         _this.$Message.info('登录失败请检查用户名和密码')
      //       }
      //     }).catch(() => {
      //       _this.$Message.error('登录异常')
      //     })
      //   }
      // })
    }
  }
}
</script>

<style lang="scss">
  .loginMain{
    position: fixed;
    top: 50%;
    left: 50%;
    width: 400px;
    height: 230px;
    padding-left: 420px;
    margin: -150px 0 0 -411px;
    background: url(../assets/dl-bgc.png) repeat-x;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -moz-border-radius: 5px;
    background-clip: padding-box;
    box-shadow: 0 0 25px #cac6c6;
    border: 1px solid #eaeaea;
    // overflow: hidden;
    &:before{
      position: absolute;
      top: 0;
      left: -3px;
      content: '';
      height: 230px;
      width: 378px;
      background: url(../assets/dl-bg.png) no-repeat center center;
    }
    &:after{
      position: absolute;
      top: -48px;
      left: 10px;
      content: '';
      height: 38px;
      width: 310px;
      //background: url(../assets/dl-LOGO.png) no-repeat center center;
    }
    .login-container {
      position: relative;
      color: #fff;
      width: 350px;
      padding: 64px 0 0 60px;
      &:before{
        position: absolute;
        top: 0;
        left: -3px;
        content: '';
        height: 230px;
        width: 2px;
        background: url(../assets/dl-line.png) no-repeat center center;
      }
      .el-form-item__label{
        width: 46px;
        margin-right: 10px;
        color: #fff;
        text-align:justify;
        text-justify:distribute-all-lines;/*ie6-8*/
        text-align-last:justify;/* ie9*/
        -moz-text-align-last:justify;/*ff*/
        -webkit-text-align-last:justify;/*chrome 20+*/
        &:before{
          display: none;
        }
      }
      .el-checkbox__input.is-checked + .el-checkbox__label {
        color: #fff;
      }
      .el-button--images{
        width: 64px;
        height: 28px;
        background: url(../assets/dl-button.png) no-repeat;
        background-size: 100% auto;
        color: #c6c518;
        border: none;
        box-shadow: 0 0 10px rgba(10, 132, 131, .5);
        &:hover{
          color: rgba(198, 197, 24, .5);
        }
      }
      .btn-mg{
        margin: 10px 0 0 54px;
      }
    }
  }
</style>
