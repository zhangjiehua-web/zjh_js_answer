<template>
  <div>
    <el-row>
      <el-col :span="24">
        <el-menu default-active="0" mode="horizontal">
          <el-menu-item index="0" @click="jumpHome">主页</el-menu-item>
          <el-menu-item index="1" @click="jumpTable">表格</el-menu-item>
          <el-menu-item index="2" @click="jumpForm">表单</el-menu-item>
          <el-menu-item index="3" @click="jumpTree">树</el-menu-item>
        </el-menu>
      </el-col>
      <el-col :span="4" :style="{height:(screenHeight - 62) +'px'}" class="main">
        <aside :style="{height:(screenHeight - 62) +'px'}">
          <!--根据topmenu变化的侧边栏-->
          <el-menu default-active="$route.path" class="el-menu-vertical-demo" router>
            <template v-for="item in items">
              <template v-if="item.subs">
                <el-submenu :index="item.index" :key="item.index">
                  <template slot="title">
                    <i :class="item.icon"></i><span slot="title">{{ item.title }}</span>
                  </template>
                  <template v-for="subItem in item.subs">
                    <el-submenu v-if="subItem.subs" :index="subItem.index" :key="subItem.index">
                      <template slot="title">{{ subItem.title }}</template>
                      <el-menu-item v-for="(threeItem,i) in subItem.subs" :key="i" :index="threeItem.index" @click="addTab">
                        {{ threeItem.title }}
                      </el-menu-item>
                    </el-submenu>
                    <el-menu-item v-else :index="subItem.index" :key="subItem.index" @click="addTab">
                      {{ subItem.title }}
                    </el-menu-item>
                  </template>
                </el-submenu>
              </template>
              <template v-else>
                <el-menu-item :index="item.index" :key="item.index" @click="addTab">
                  <i :class="item.icon"></i><span slot="title">{{ item.title }}</span>
                </el-menu-item>
              </template>
            </template>
          </el-menu>
        </aside>
      </el-col>
      <el-col :span="20" :style="{height:(screenHeight - 62) +'px'}" class="main">
        <el-tabs v-model="editableTabsValue" type="card" @tab-remove="removeTab" @tab-click="handleClick">
          <el-tab-pane
            type="border-card"
            v-for="(item) in editableTabs"
            :key="item.path"
            :label="item.title"
            :name="item.name"
            :closable="item.title === '主页'?false:true">
          </el-tab-pane>
          <section  :style="{height:(screenHeight - 117) +'px'}">
            <router-view></router-view>
          </section>
        </el-tabs>
      </el-col>
    </el-row>
  </div>
</template>

<script>
// import bus from './bus'
import items from '../../common/datas.js'
let _this = null
export default {
  name: 'home',
  data () {
    return {
      screenHeight: document.documentElement.clientHeight, // 屏幕高度
      screenWidth: document.documentElement.clientWidth - 250, // 屏幕宽度
      items: [],
      editableTabs: [
        {
          title: '主页',
          name: '0',
          path: 'home'
        }
      ],
      highLight: '0',
      tabIndex: 0,
      editableTabsValue: '0'
    }
  },
  created () {
    _this = this
    _this.items = items.home
    if (_this.$route.path !== '/home') {
      let item = _this.$route.path.replace('/', '')
      // _this.items = items[item]
      _this.editableTabs.push({
        title: _this.$route.name,
        name: '1',
        path: item
      })
      _this.tabIndex = 1
      _this.editableTabsValue = '1'
    }
  },
  methods: {
    jumpHome () {
      _this.items = items.home
    },
    jumpTable () {
      _this.items = items.table
      console.log(_this.items[0].highLight)
    },
    jumpForm () {
      _this.items = items.form
    },
    jumpTree () {
      _this.items = items.tree
    },
    removeTab (targetName) {
      let tabs = _this.editableTabs
      let activeName = _this.editableTabsValue
      if (activeName === targetName) {
        tabs.forEach((tab, index) => {
          if (tab.name === targetName) {
            let nextTab = tabs[index + 1] || tabs[index - 1]
            if (nextTab) {
              activeName = nextTab.name
              _this.editableTabs.forEach((i, index) => {
                if (i.name === activeName) {
                  _this.$router.push({path: '/' + i.path})
                }
              })
            } else {
              _this.tabIndex = 0
              _this.editableTabsValue = '0'
              _this.$router.push({path: '/home'})
            }
          }
        })
      }
      _this.editableTabsValue = activeName
      _this.editableTabs = tabs.filter(tab => tab.name !== targetName)
    },
    addTab (targetName) {
      let newTabName = null
      let nowsub = []
      let num = 0
      _this.editableTabs.forEach((i, index) => {
        if (i.path === targetName.index) {
          newTabName = i.name
          num++
        } else {
          if (_this.items[0].subs) {
            for (let j = 0; j < _this.items[0].subs.length; j++) {
              if (targetName.index === _this.items[0].subs[j].index) {
                nowsub = _this.items[0].subs[j]
                break
              }
            }
          } else {
            for (let j = 0; j < _this.items.length; j++) {
              if (targetName.index === _this.items[j].index) {
                nowsub = _this.items[j]
                break
              }
            }
          }
        }
      })
      if (num === 0) {
        newTabName = ++_this.tabIndex + ''
        _this.editableTabs.push({
          title: nowsub.title,
          name: newTabName,
          path: nowsub.index
        })
      }
      _this.editableTabsValue = newTabName
    },
    handleClick (tab) {
      _this.$router.push({path: '/' + _this.editableTabs[tab.index].path})
    }
  }
}
</script>

<style lang="scss">
  html,body{
    margin: 0;
    padding: 0;
  }
  aside{
    background: aliceblue;
    overflow: auto;
  }
</style>
