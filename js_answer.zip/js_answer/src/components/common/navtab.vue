<template>
<div></div>
</template>

<script>
// import bus from './bus'
export default {
  name: 'navtab'
}
</script>

<style scoped>

</style>
