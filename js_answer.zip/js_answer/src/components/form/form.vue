<template>
  <div>
    form
  </div>
</template>

<script>
export default {
  name: 'form'
}
</script>

<style scoped>

</style>
