<template>
    <div>form2</div>
</template>

<script>
export default {
  name: 'form2'
}
</script>

<style scoped>

</style>
