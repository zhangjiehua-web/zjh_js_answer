import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/login'
    },
    {
      path: '/login',
      name: '登录',
      component: resolve => require(['@/components/login.vue'], resolve)
    },
    {
      path: '/home',
      name: 'home',
      component: resolve => require(['../components/common/home.vue'], resolve),
      children: [
        {
          path: '/',
          name: '主页',
          component: resolve => require(['@/components/HelloWorld.vue'], resolve)
        },
        {
          path: '/datatable',
          name: '表格',
          component: resolve => require(['@/components/table/datatable.vue'], resolve)
        },
        {
          path: '/datatableMock',
          name: '表格Mock',
          component: resolve => require(['@/components/table/datatableMock.vue'], resolve)
        },
        {
          path: '/addrow',
          name: '动态添加表格行',
          component: resolve => require(['@/components/table/addrow.vue'], resolve)
        },
        {
          path: '/eltree',
          name: '树',
          component: resolve => require(['@/components/tree/eltree.vue'], resolve)
        },
        {
          path: '/form',
          name: '表单',
          component: resolve => require(['@/components/form/form.vue'], resolve)
        },
        {
          path: '/form2',
          name: '表单2',
          component: resolve => require(['@/components/form/form2.vue'], resolve)
        }
      ]
    }
  ]
})
