export default {
  // 默认地址
  gateway_url: '',
  // 分页信息
  page: {total: 0, pageSize: 10, currentPage: 1, pageSizes: [10, 50, 100]},
  // 登录信息key
  logInfo: {
    user: 'sgcc_user'
  }
}
