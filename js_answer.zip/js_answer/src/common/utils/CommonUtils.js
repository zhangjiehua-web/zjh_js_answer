// 通用工具类
export default class CommonUtils {
  /**
   * 初始化翻页数据
   * @param _this 当前vue对象
   * @param functionObj 每次页变动后回调方法
   */
  static init (_this) {
    _this.page = _this.page == null ? this.deepClone(_this.$Config.page) : _this.page
    _this.currentChange = function (page) {
      _this.page.currentPage = page
      _this.tableData = _this.tableDataint.slice((_this.page.currentPage - 1) * _this.page.pageSize, _this.page.currentPage * _this.page.pageSize)
    }
    _this.sizeChange = function (size) {
      _this.page.pageSize = size
      _this.tableData = _this.tableDataint.slice((_this.page.currentPage - 1) * _this.page.pageSize, _this.page.currentPage * _this.page.pageSize)
    }
  }
  /**
   * 深度拷贝数据
   * @param source 元数据
   * @param ignoreNull 是否拷贝集合
   * @returns 拷贝后的集合
   */
  static deepClone (source, ignoreNull) {
    if (!source || typeof source !== 'object') {
      throw new Error('error arguments', 'shallowClone')
    }
    if (ignoreNull == null) {
      ignoreNull = false
    }
    let targetObj = source.constructor === Array ? [] : {}
    for (let keys in source) {
      if (source.hasOwnProperty(keys)) {
        if (source[keys] && typeof source[keys] === 'object') {
          targetObj[keys] = source[keys].constructor === Array ? [] : {}
          targetObj[keys] = this.deepClone(source[keys])
        } else {
          if (ignoreNull) {
            if (source[keys] != null && source[keys] !== '') {
              targetObj[keys] = source[keys]
            }
          } else {
            targetObj[keys] = source[keys]
          }
        }
      }
    }
    return targetObj
  }
}
