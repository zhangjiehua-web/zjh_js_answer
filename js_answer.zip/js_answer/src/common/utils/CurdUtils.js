//  'axios'请求工具类
import axios from 'axios'
export default class Utils {
  static query () {
    console.log(axios)
  }
}
