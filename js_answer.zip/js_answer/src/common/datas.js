const home = [
  {
    icon: 'el-icon-tickets',
    index: 'home',
    title: '主页',
    highLight: '0'
  }
]
const table = [
  {
    icon: 'el-icon-tickets',
    index: '',
    title: '表格',
    highLight: '1',
    subs: [
      {
        index: 'datatable',
        title: '表格'
      },
      {
        index: 'datatableMock',
        title: '表格Mock'
      },
      {
        index: 'addrow',
        title: '动态添加表格行'
      }
    ]
  }
]
const tree = [
  {
    icon: 'el-icon-tickets',
    index: 'eltree',
    title: '树',
    highLight: '2'
  }
]
const form = [
  {
    icon: 'el-icon-tickets',
    index: 'form',
    title: '表单',
    highLight: '3'
  },
  {
    icon: 'el-icon-tickets',
    index: 'form2',
    title: '表单2',
    highLight: '3'
  }
]
const login = [
  {
    icon: 'el-icon-tickets',
    index: 'login',
    title: '登录'
  }
]
export default {
  home,
  table,
  tree,
  form,
  login
}
